# IslamicDigitalWall
Skeleton Android project.